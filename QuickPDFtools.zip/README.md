# QuickPDFtools

A simple web app to Merge and Compress PDF files in the browser.

## How to Use
1. Upload PDFs to merge or compress.
2. Click the respective button.
3. Download your processed PDF automatically.

## Hosting on GitHub Pages
1. Create a new repository.
2. Upload these files to the root directory.
3. Go to **Settings → Pages → Source → main branch / root**.
4. Visit your live URL.
